<!-- /page content -->
</div>
<!-- footer content -->
<footer>
    <div class="pull-right">
        Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src=<?= base_url("dist_adm/gentelella/vendors/jquery/dist/jquery.min.js") ?>></script>
<!-- Bootstrap -->
<script src=<?= base_url("dist_adm/gentelella/vendors/bootstrap/dist/js/bootstrap.min.js") ?>></script>

<!-- FastClick -->
<script src=<?= base_url("dist_adm/gentelella/vendors/fastclick/lib/fastclick.js") ?>></script>
<!-- NProgress -->
<script src=<?= base_url("dist_adm/gentelella/vendors/nprogress/nprogress.js") ?>></script>

<!-- Custom Theme Scripts -->
<script src=<?= base_url("dist_adm/gentelella/build/js/custom.min.js") ?>></script>

<!-- bootstrap-progressbar -->
<script src=<?= base_url("dist_adm/gentelella/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js") ?>></script>
<!-- iCheck -->
<script src=<?= base_url("dist_adm/gentelella/vendors/iCheck/icheck.min.js") ?>></script>
<!-- bootstrap-daterangepicker -->
<script src=<?= base_url("dist_adm/gentelella/vendors/moment/min/moment.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/bootstrap-daterangepicker/daterangepicker.js") ?>></script>
<!-- bootstrap-wysiwyg -->
<script src=<?= base_url("dist_adm/gentelella/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/jquery.hotkeys/jquery.hotkeys.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/google-code-prettify/src/prettify.js") ?>></script>
<!-- jQuery Tags Input -->
<script src=<?= base_url("dist_adm/gentelella/vendors/jquery.tagsinput/src/jquery.tagsinput.js") ?>></script>
<!-- Switchery -->
<script src=<?= base_url("dist_adm/gentelella/vendors/switchery/dist/switchery.min.js") ?>></script>
<!-- Select2 -->
<script src=<?= base_url("dist_adm/gentelella/vendors/select2/dist/js/select2.full.min.js") ?>></script>
<!-- Parsley -->
<script src=<?= base_url("dist_adm/gentelella/vendors/parsleyjs/dist/parsley.min.js") ?>></script>
<!-- Autosize -->
<script src=<?= base_url("dist_adm/gentelella/vendors/autosize/dist/autosize.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js") ?>></script>
<!-- starrr -->
<script src=<?= base_url("dist_adm/gentelella/vendors/starrr/dist/starrr.js") ?>></script>

<!-- Table Dynamic -->
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net/js/jquery.dataTables.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-buttons/js/dataTables.buttons.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-buttons/js/buttons.flash.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-buttons/js/buttons.html5.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-buttons/js/buttons.print.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-responsive/js/dataTables.responsive.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/datatables.net-scroller/js/dataTables.scroller.min.js") ?>></script>

<script src=<?= base_url("dist_adm/gentelella/vendors/jszip/dist/jszip.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/pdfmake/build/pdfmake.min.js") ?>></script>
<script src=<?= base_url("dist_adm/gentelella/vendors/pdfmake/build/vfs_fonts.js") ?>></script>

<script src=<?= base_url("dist_adm/gentelella/vendors/dropzone/dist/min/dropzone.min.js") ?>></script>
<!-- Boostrap input Scripts -->
<script src=<?= base_url("dist_adm/input/js/plugins/canvas-to-blob.min.js") ?>></script>
<script src=<?= base_url("dist_adm/input/js/plugins/sortable.min.js") ?>></script>
<script src=<?= base_url("dist_adm/input/js/plugins/purify.min.js") ?>></script>
<script src=<?= base_url("dist_adm/input/js/fileinput.min.js") ?>></script>
<script src=<?= base_url("dist_adm/input/js/locales/pt-BR.js") ?>></script>
<script>
    $("#userfile").fileinput({
        language: "pt-BR",
        allowedFileExtensions: ["jpg", "png", "jpeg"]
    });
</script>
<!-- Modal Scripts -->

<!-- Custom Theme Scripts -->
<script src=<?= base_url("dist_adm/custom-junior.js") ?>></script>


</body>
</html>